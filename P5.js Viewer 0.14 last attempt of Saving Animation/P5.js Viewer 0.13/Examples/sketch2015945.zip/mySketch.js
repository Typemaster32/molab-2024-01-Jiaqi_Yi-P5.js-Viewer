let z = 125; //unit size
let z1 = (z * 1.73205) / 2;
let z2 = z1 - z / 2;

let sw_frontier = 20;
let sw_shade = 34;
let sw_white = 80;
let sw_poly = 6; //strokeweight

let os_shade = 0;
let os_frontier = 0;
let os_white = 0; //take a try!

let c_frontier;
let c_shade;
let c_white; //colors

let col_max;
let row_max;

let p; //let [][]p=new int[col_max][row_max];
let inf; //let [][]inf=new int[col_max][row_max];

let off = 0.05;
function setup() {
  createCanvas(windowWidth, windowHeight);
  strokeCap(SQUARE);
  c_frontier = color(25, 11, 11);
  c_shade = color(205);
  c_white = color(255);

  col_max = round(1600 / z) + 1;
  row_max = round(1600 / ((z / 2) * 1.73205)) + 1;

  p = create2DArray(col_max, row_max);
  inf = create2DArray(col_max, row_max);
}
function draw() {
  background(233, 233, 243);
  for (let row = 0; row < row_max; row++) {
    for (let col = 0; col < col_max; col++) {
      if (col % 2 == 0) {
        inf[col][row] = row % 4;
      } else {
        inf[col][row] = (row + 2) % 4;
      }
      p[col][row] = round(random(1));
    }
  }
  for (let row = 0; row < row_max; row++) {
    for (let col = 0; col < col_max; col++) {
      game_under(col, row, inf[col][row], p[col][row]);
      game_poly(col, row, inf[col][row], p[col][row]);
      game_upper(col, row, inf[col][row], p[col][row]);
    }
  }
  noLoop();
}
function create2DArray(a, b) {
  // Initialize an empty 2D array
  const array2D = [];

  // Outer loop to create rows
  for (let i = 0; i < a; i++) {
    // Initialize an empty row
    const row = [];

    // Inner loop to create columns in each row
    for (let j = 0; j < b; j++) {
      // You can initialize the values as needed here
      // For example, if you want to initialize with zeros:
      // row.push(0);

      // Push the element to the row
      row[j] = 0;
      //row.push(0); // You can use any initial value here
    }

    // Push the row to the 2D array
    // array2D.push(row);
    array2D[i] = row;
  }

  return array2D;
}

// Example usage: Create a 3x4 2D array
const myArray = create2DArray(3, 4);

function game_under(col, row, inf, p) {
  push();
  let x;
  let y = row * z1;
  let theta = ((inf + 1) * PI) / 2;
  if (row % 2 == 0) {
    x = z1 + (z2 * 2 + z) * col - 2 * z;
  } else {
    x = z1 * 2 + (z2 * 2 + z) * col - 2 * z;
  }
  translate(x, y);
  rotate(theta);
  noFill();
  if (p == 1) {
    stroke(c_white);
    strokeWeight(sw_white);
    arc(
      2 * z1,
      (-z * 3) / 2,
      (2 * z + sw_white / 2) * 2,
      (2 * z + sw_white / 2) * 2,
      (PI * 2) / 3,
      (PI * 5) / 6,
      OPEN
    );
    arc(
      2 * z1,
      (-z * 3) / 2,
      ((1.73205 + 1) * z - sw_white / 2) * 2,
      ((1.73205 + 1) * z - sw_white / 2) * 2,
      (PI * 2) / 3,
      (PI * 5) / 6,
      OPEN
    );
    stroke(c_shade);
    strokeWeight(sw_shade);
    arc(
      2 * z1,
      (-z * 3) / 2,
      (2 * z + sw_shade / 2) * 2,
      (2 * z + sw_shade / 2) * 2,
      (PI * 2) / 3,
      (PI * 5) / 6,
      OPEN
    );
    arc(
      2 * z1,
      (-z * 3) / 2,
      ((1.73205 + 1) * z - sw_shade / 2) * 2,
      ((1.73205 + 1) * z - sw_shade / 2) * 2,
      (PI * 2) / 3,
      (PI * 5) / 6,
      OPEN
    );
    stroke(c_frontier);
    strokeWeight(sw_frontier);
    arc(
      2 * z1,
      (-z * 3) / 2,
      (2 * z + sw_frontier / 2) * 2,
      (2 * z + sw_frontier / 2) * 2,
      (PI * 2) / 3 - off,
      (PI * 5) / 6,
      OPEN
    );
    arc(
      2 * z1,
      (-z * 3) / 2,
      ((1.73205 + 1) * z - sw_frontier / 2) * 2,
      ((1.73205 + 1) * z - sw_frontier / 2) * 2,
      (PI * 2) / 3 - off,
      (PI * 5) / 6,
      OPEN
    );
    //0-3 door
  } else {
    ////0-1 door
    stroke(c_white);
    strokeWeight(sw_white);
    arc(
      z1,
      0,
      (z - sw_white / 2) * 2,
      (z - sw_white / 2) * 2,
      (PI * 2) / 3,
      (PI * 7) / 6,
      OPEN
    );
    arc(
      z1,
      0,
      ((2 - 1.73205) * z + sw_white / 2) * 2,
      ((2 - 1.73205) * z + sw_white / 2) * 2,
      (PI * 2) / 3,
      (PI * 7) / 6,
      OPEN
    );
    stroke(c_shade);
    strokeWeight(sw_shade);
    arc(
      z1,
      0,
      (z - sw_shade / 2) * 2,
      (z - sw_shade / 2) * 2,
      (PI * 2) / 3,
      (PI * 7) / 6,
      OPEN
    );
    arc(
      z1,
      0,
      ((2 - 1.73205) * z + sw_shade / 2) * 2,
      ((2 - 1.73205) * z + sw_shade / 2) * 2,
      (PI * 2) / 3,
      (PI * 7) / 6,
      OPEN
    );
    stroke(c_frontier);
    strokeWeight(sw_frontier);
    arc(
      z1,
      0,
      (z - sw_frontier / 2) * 2,
      (z - sw_frontier / 2) * 2,
      (PI * 2) / 3 - off,
      (PI * 7) / 6,
      OPEN
    );
    arc(
      z1,
      0,
      ((2 - 1.73205) * z + sw_frontier / 2) * 2,
      ((2 - 1.73205) * z + sw_frontier / 2) * 2,
      (PI * 2) / 3 - off,
      (PI * 7) / 6,
      OPEN
    );
    //4-3 door
  }
  pop();
}
function game_upper(col, row, inf, p) {
  push();
  let x;
  let y = row * z1;
  let theta = ((inf + 1) * PI) / 2;
  if (row % 2 == 0) {
    x = z1 + (z2 * 2 + z) * col - 2 * z;
  } else {
    x = z1 * 2 + (z2 * 2 + z) * col - 2 * z;
  }
  translate(x, y);
  rotate(theta);
  noFill();
  if (p == 1) {
    stroke(c_white);
    strokeWeight(sw_white);
    arc(
      -2 * z1,
      (-z * 3) / 2,
      (2 * z + sw_white / 2) * 2,
      (2 * z + sw_white / 2) * 2,
      PI / 6,
      PI / 3,
      OPEN
    );
    arc(
      -2 * z1,
      (-z * 3) / 2,
      ((1.73205 + 1) * z - sw_white / 2) * 2,
      ((1.73205 + 1) * z - sw_white / 2) * 2,
      PI / 6,
      PI / 3,
      OPEN
    );
    stroke(c_shade);
    strokeWeight(sw_shade);
    arc(
      -2 * z1,
      (-z * 3) / 2,
      (2 * z + sw_shade / 2) * 2,
      (2 * z + sw_shade / 2) * 2,
      PI / 6,
      PI / 3,
      OPEN
    );
    arc(
      -2 * z1,
      (-z * 3) / 2,
      ((1.73205 + 1) * z - sw_shade / 2) * 2,
      ((1.73205 + 1) * z - sw_shade / 2) * 2,
      PI / 6,
      PI / 3,
      OPEN
    );
    stroke(c_frontier);
    strokeWeight(sw_frontier);
    arc(
      -2 * z1,
      (-z * 3) / 2,
      (2 * z + sw_frontier / 2) * 2,
      (2 * z + sw_frontier / 2) * 2,
      PI / 6 - off,
      PI / 3,
      OPEN
    );
    arc(
      -2 * z1,
      (-z * 3) / 2,
      ((1.73205 + 1) * z - sw_frontier / 2) * 2,
      ((1.73205 + 1) * z - sw_frontier / 2) * 2,
      PI / 6 - off,
      PI / 3,
      OPEN
    );
  } else {
    stroke(c_white);
    strokeWeight(sw_white);
    arc(
      -z1,
      0,
      (z - sw_white / 2) * 2,
      (z - sw_white / 2) * 2,
      (PI * 11) / 6,
      2 * PI,
      OPEN
    );
    arc(
      -z1,
      0,
      (z - sw_white / 2) * 2,
      (z - sw_white / 2) * 2,
      0,
      PI / 3,
      OPEN
    );
    arc(
      -z1,
      0,
      ((2 - 1.73205) * z + sw_white / 2) * 2,
      ((2 - 1.73205) * z + sw_white / 2) * 2,
      (PI * 11) / 6,
      2 * PI,
      OPEN
    );
    arc(
      -z1,
      0,
      ((2 - 1.73205) * z + sw_white / 2) * 2,
      ((2 - 1.73205) * z + sw_white / 2) * 2,
      0,
      PI / 3,
      OPEN
    );
    stroke(c_shade);
    strokeWeight(sw_shade);
    arc(
      -z1,
      0,
      (z - sw_shade / 2) * 2,
      (z - sw_shade / 2) * 2,
      (PI * 11) / 6,
      2 * PI,
      OPEN
    );
    arc(
      -z1,
      0,
      (z - sw_shade / 2) * 2,
      (z - sw_shade / 2) * 2,
      0,
      PI / 3,
      OPEN
    );
    arc(
      -z1,
      0,
      ((2 - 1.73205) * z + sw_shade / 2) * 2,
      ((2 - 1.73205) * z + sw_shade / 2) * 2,
      (PI * 11) / 6,
      2 * PI,
      OPEN
    );
    arc(
      -z1,
      0,
      ((2 - 1.73205) * z + sw_shade / 2) * 2,
      ((2 - 1.73205) * z + sw_shade / 2) * 2,
      0,
      PI / 3,
      OPEN
    );
    stroke(c_frontier);
    strokeWeight(sw_frontier);
    arc(
      -z1,
      0,
      (z - sw_frontier / 2) * 2,
      (z - sw_frontier / 2) * 2,
      (PI * 11) / 6 - off,
      2 * PI,
      OPEN
    );
    arc(
      -z1,
      0,
      (z - sw_frontier / 2) * 2,
      (z - sw_frontier / 2) * 2,
      0,
      PI / 3,
      OPEN
    );
    arc(
      -z1,
      0,
      ((2 - 1.73205) * z + sw_frontier / 2) * 2,
      ((2 - 1.73205) * z + sw_frontier / 2) * 2,
      (PI * 11) / 6 - off,
      2 * PI,
      OPEN
    );
    arc(
      -z1,
      0,
      ((2 - 1.73205) * z + sw_frontier / 2) * 2,
      ((2 - 1.73205) * z + sw_frontier / 2) * 2,
      0,
      PI / 3,
      OPEN
    );
    ////0-1 door
  }
  pop();
}
function game_poly(col, row, inf, p) {
  push();
  let x;
  let y = row * z1;
  let theta = ((inf + 1) * PI) / 2;
  if (row % 2 == 0) {
    x = z1 + (z2 * 2 + z) * col - 2 * z;
  } else {
    x = z1 * 2 + (z2 * 2 + z) * col - 2 * z;
  }
  translate(x, y);
  rotate(theta);
  noFill();
  strokeWeight(sw_poly);
  stroke(134, 196, 186);
  beginShape();
  vertex(0, -z / 2 + sw_poly);
  vertex(z1 - sw_poly * 1.5, 0);
  vertex(z2 - sw_poly, z1 - sw_poly);
  vertex(-z2 + sw_poly, z1 - sw_poly);
  vertex(-z1 + sw_poly * 1.5, 0);
  endShape(CLOSE);
  pop();
}
function keyReleased() {
  if (key == 's' || key == 'S') saveCanvas('Disordered_Jiaqi_Yi', 'png');}
