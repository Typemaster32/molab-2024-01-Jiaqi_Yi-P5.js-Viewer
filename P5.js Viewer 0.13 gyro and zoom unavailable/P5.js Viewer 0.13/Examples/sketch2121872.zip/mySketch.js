let radius;
let center;
let angNum;
let notchWidth;
/*
Parameters_1: Paramenters that change with the size
*/
let notchMax = 8;
let branchMax = 60;
let branchGaussian = 1.4;
let branchLengthStandard = 60;
let branchCurveness = 6;
let thickness = 2.7;
let enclosingThickness = 0.5;
let wreckleness = 4;
let inkColor;
/*
Parameters_2: Paramenters that are customized
*/
let pixelDens = 1;
/*
Parameters_3: General settings of the canvas
*/
let blurDistance = 0.9;
let noiseScale = 0.015;
let noiseIndex = 0;
/*
Parameters_4: Parameters of motion blurring
*/
let xy_increment = 3;
let z_increment = 0.04;
let unit = 10;
let colorOff = 0;
let z_off;
let noiseDistributionProportionStandard = 0.03;
let threshold = 3;
/*
Parameters_5: The fog and glass effect (as  mask)
*/
let textBox;
let tbWidth = 1000;
let tbHeight = 30;
let publicFont = "Arial";
let publicFontSize = 36;
/*
Parameters_6: The Input and Interaction
*/
let mainSize;
let maxSize;
let minorSize;
let notchNum;
let notches = [];
let branchNum;
let branches = [];

/*
Parameters_7: Moving the parameters out of setup
*/
let click = false;
let attack = 5500;
let decay = 1500;
let sustain = 3500;
let release = 5500;
//in millis
let startingTime = 0;
let aoa = [];
let peak = -0.07;
/*
Parameters_8: The feature of showing up;
*/
let collection = [];
let numOfCollection = 8;
let wth;
let hght;
let rim = 30;
let graphicsIndex = 0;
let graphicsMax;
let colNum;
let rowNum;
let transfrom;
let scale = 3;
let collectionColor;
let proportionScreen;
let proportionCollection = 4;
let centralOffset;
let projectWidth;
let projectHeight;
let projectMax;
let projectOffset;
let startToDisplay = false;
/*
Parameter_9: The collection of the conversation
*/
let questions = [];
let numOfQuestion = numOfCollection;
let locations = [];
let answering = false;
let updated = false;
/*
Parameter_10: The questions raised by users
*/
let mainCanvas;
let textCanvas;

/*
Parameter_11: The Layer of texts
*/

let revival;
/*
Parameter_12: Only of Web-editor Version
*/

/*
The TODO List:
1. Improve the Show Up and Go process;
2. Indications of the status;
3. Proper stickers arrangements;
4. Prepare the questions and Input system;
*/

function setup() {
  //textFont(publicFont);
  textSize(publicFontSize);
  mainCanvas = createCanvas(windowWidth, windowHeight);
  //textCanvas=createCanvas(windowWidth, windowHeight);
  textAlign(CENTER, TOP);
  strokeCap(ROUND);
  angleMode(RADIANS);
  //background("white");
  pixelDensity(1);
  strokeWeight(2);
  frameRate(24);
  noiseDetail(2, 0.12);
  push();
  noStroke();
  fill(255, 255, 255);
  rect(0, 0, width, height);
  pop();
  inkColor = color(10, 10, 10);
  collectionColor = color(225, 0, 0);
  mainSize = min(windowWidth, windowHeight);
  maxSize = max(windowWidth, windowHeight);
  wth = width;
  hght = height;
  radius = mainSize * 0.27;
  angNum = floor(PI * 4 * 100) + 1;
  center = createVector(width / 2, height / 2);
  notchWidth = floor(random(18, 26));
  revival =
    attack + decay + sustain + release + max(attack, decay, sustain, release);
  //console.log(revival);
  for (let i = 0; i < 24; i++) {
    let sticker = createGraphics(windowWidth, windowHeight);
    collection.push(sticker);
  }
  /*
  <<0-1. Setting the Universal Parameters!
  */

  proportionScreen = maxSize / mainSize;
  projectWidth = maxSize / proportionCollection;
  projectHeight = mainSize / proportionCollection;
  projectOffset = (maxSize / 2 - radius) / proportionCollection;
  projectOffset *= 0.8;
  colNum = floor(maxSize / (projectWidth - projectOffset * 2));
  rowNum = proportionCollection;
  projectMax = colNum * proportionCollection;
  //console.log(projectMax);
  centralOffset = (maxSize - colNum * (projectWidth - projectOffset * 2)) / 2;

  /*
  << 0-0. The Mode of Canvas
  Setting Parameters >>
  */

  fakeClick();
}

function draw() {
  /*
  << 3-4. To apply a immortal layer, you have to constantly draw the ring.
  */
  let timePassed = millis() - startingTime;
  // timePassed HAS TO BE THE FIRST since everything relies on it.
  let lerping = 0;
  let mapping = 0;
  let noiseDistributionProportion = 0;
  if (aoa.length > 0) {
    noiseDistributionProportion =
      timePassed / (attack + decay + sustain + release);
    if (timePassed < attack) {
      mapping = map(timePassed, 0, attack, 0.5, peak);
      lerping = mapping;
      // console.log("Attacking");
    } else if (timePassed < attack + decay) {
      lerping = map(timePassed - attack, 0, decay, peak, 0);
      // console.log("Decaying");
    } else if (timePassed < attack + decay + sustain) {
      lerping = 0;
      // console.log("Sustaining");
    } else if (timePassed < attack + decay + sustain + release) {
      lerping = map(timePassed - attack - decay - sustain, 0, release, 0, 0.5);
      //noiseDistributionProportion = pow(noiseDistributionProportion, 3)
      // console.log("Releasing");
    } else if (timePassed >= attack + decay + sustain + release) {
      // startingTime = 0;
      click = false;
      // collect();
      aoa = [];
      //console.log("Finish");
      // startToDisplay = true;
    }
    if (aoa.length > 0) {
      for (let i = 0; i < aoa.length; i++) {
        // if (i = 7) { console.log(lerping) }
        let pointLerpedA = aoa[i][0].copy();
        let pointLerpedB = aoa[i][1].copy();
        pointLerpedA.lerp(aoa[i][1], lerping);
        pointLerpedB.lerp(aoa[i][0], lerping);
        line(pointLerpedA.x, pointLerpedA.y, pointLerpedB.x, pointLerpedB.y);
        //line(aoa[i][0].x, aoa[i][0].y, aoa[i][1].x, aoa[i][1].y);
      }
    }
  }
  if (timePassed >= revival) {
    fakeClick();
  }
  /*
  << 8-1. The Showing Up and Passing Away of Arrival
  (Passing is not quite here. It is also affected by diffusion)
  */
  loadPixels();
  let pixelNum = width * height;
  for (let i = 0; i < pixelNum; i++) {
    let posX = i % width;
    let posY = floor(i / width);
    let colorOff = sin(z_off);
    let noiseVal = noise(
      (posX / width) * xy_increment,
      (posY / height) * xy_increment,
      z_off
    );
    let rNoise = 230 - noiseVal * 194 + colorOff * 10;
    let gNoise = 230 - noiseVal * 184 + colorOff * 12;
    let bNoise = 230 - noiseVal * 186 + colorOff * 16;
    let rArrival = pixels[i * 4];
    let gArrival = pixels[i * 4 + 1];
    let bArrival = pixels[i * 4 + 2];

    if (
      rNoise - rArrival >= 5 &&
      timePassed < attack + decay + sustain + release &&
      aoa.length > 0
    ) {
      let orientation = random(2 * PI);
      let deltaX = round(cos(orientation) * blurDistance);
      let deltaY = round(sin(orientation) * blurDistance);
      let destination = width * (deltaY + posY) + (deltaX + posX);

      if (pixels[destination * 4] != rArrival) {
        pixels[destination * 4 + 2] = round(
          bNoise * noiseDistributionProportion +
            bArrival * (1 - noiseDistributionProportion)
        );
        pixels[destination * 4 + 1] = round(
          gNoise * noiseDistributionProportion +
            gArrival * (1 - noiseDistributionProportion)
        );
        pixels[destination * 4 + 0] = round(
          rNoise * noiseDistributionProportion +
            rArrival * (1 - noiseDistributionProportion)
        );
      }
    }
    // else if (timePassed < attack + decay + sustain * 4) {
    //   pixels[i * 4] = rNoise * 0.9 + pixels[i * 4] * 0.1;
    //   pixels[i * 4 + 1] = gNoise * 0.9 + pixels[i * 4 + 1] * 0.1;
    //   pixels[i * 4 + 2] = bNoise * 0.9 + pixels[i * 4 + 2] * 0.1;
    // }
    else {
      pixels[i * 4] = rNoise;
      pixels[i * 4 + 1] = gNoise;
      pixels[i * 4 + 2] = bNoise;
    }
  }
  z_off += z_increment;
  updatePixels();
  /*
  << 3-3. Motion blur of the ring (DIFFUSION)
  && 4-2. Mask with noise and the application
  */

  // if (startToDisplay) {
  //   push();
  //   fill(collectionColor);
  //   displayAoa();
  //   pop();
  // }

  /*
  << TESTING >>
  */
}

function arrival() {
  let arrayOfArrival = [];
  /*
   ** Extra: creating an array to store the ring
   */
  notchNum = floor(random(notchMax));
  branchNum = floor(random(notchMax)) * branchMax;
  /*
  <<0-2. Basic Variables related to Notches and Branches
  */
  let startNotch = 0;
  for (let i = 0; i < notchNum; i++) {
    let thisNotch = random(startNotch, (angNum * (1 + i)) / notchNum);
    notches.push(thisNotch);
    startNotch = thisNotch;
  }
  /*
  <<1-1. Preparing Array of Random Notches by counting distance with abs;
  1-2. Preparing Array of Branches not Overlapped with Notches >>
  */
  for (let j = 0; j < branchNum; j++) {
    let thisBranch;
    let thisBranchCollapse = true;
    while (thisBranchCollapse) {
      let collapse = 0;
      thisBranch = random(angNum);
      for (let k = 0; k < notchNum; k++) {
        if (abs(thisBranch - notches[k]) < notchWidth) collapse++;
      }
      if (collapse == 0) thisBranchCollapse = false;
    }
    branches.push(thisBranch);
  }

  /*
  2. Start the Main Loop >>
  */
  let rotateAngle = random(2) * PI;
  for (let i = 0; i < angNum; i++) {
    let angle = i * 0.005 + rotateAngle;
    /*
    << 2-1.Angle Related Parameters, including Steering Feature
    Width Related Parameters >>
    */
    let widOut = 0.1 * noise(wreckleness * angle);
    let widIn = 0.1 * noise(wreckleness * angle * 2);
    let widAid = 0.1 * noise((wreckleness * angle) / 4);
    let endDistance = min(angNum - i, i);
    let approachingEnd_A = endDistance / angNum;
    let approachingEnd_B = min(pow(approachingEnd_A, 2), 1) * 2;
    let approachingEnd_C = noise(i * 0.01) / 3;
    widOut *= approachingEnd_C ** enclosingThickness * thickness;
    widIn *= approachingEnd_C ** enclosingThickness * thickness;
    widAid *= approachingEnd_C ** 1 * thickness;
    /*
    << 2-2. Controll of Width, and Narrowing down when approaching End
    */
    let blank = 0;
    let gradualDecrease = 0;
    for (let j = 0; j < notches.length; j++) {
      if (abs(i - notches[j]) < notchWidth) {
        blank++;
      }
      if (blank == 0) stroke(inkColor);
      //Making the Notch, by painting it white
      if (
        abs(i - notches[j]) < notchWidth * 3 &&
        abs(i - notches[j]) > notchWidth
      ) {
        gradualDecrease++;
        widOut *= map(abs(i - notches[j]), notchWidth * 3, 0, 1, -0.5);
        widIn *= map(abs(i - notches[j]), notchWidth * 3, 0, 1, -0.5);
      }

      //Making the gradualDecrease which is the part close to the notches
    }
    /*
    << 2-3. Applying Random Notches and the Gradual Decreases
    */
    let radiusA = radius * (1 + widOut) * (1 + widAid);
    let radiusB = radius * (1 - widIn) * (1 + widAid);
    let pointA = createVector(cos(angle) * radiusA, sin(angle) * radiusA);
    let pointB = createVector(cos(angle) * radiusB, sin(angle) * radiusB);
    pointA.add(center);
    pointB.add(center);
    // This is //ed to make the graph spin
    //stroke(0,0,0);
    if (blank == 0) {
      //ßline(pointA.x, pointA.y, pointB.x, pointB.y);
      arrayOfArrival.push([pointA, pointB]);
    }
    /*
    << 3-1. Execute the Circle with Multiple Lines
    Branches System >>
    */
    for (let j = 0; j < branches.length; j++) {
      if (i == floor(branches[j])) {
        let branchLength = ((widOut + widIn) * branchLengthStandard) ** 3.1;
        let perpAngle;
        let steering;
        let beta;
        let adjustment;
        if (random(1) > 0.5) angle += PI / 2;
        else angle -= PI / 2;
        // first attempt to make branches inward
        if (random(1) > 0.5) perpAngle = angle + PI / branchCurveness;
        else perpAngle = angle - PI / branchCurveness;
        //Preparing the parameters and set the directions of the branches;
        for (let k = 0; k < branchLength + 5; k++) {
          steering = randomGaussian(k / branchLength, branchGaussian);
          beta = lerp(angle, perpAngle, steering);
          adjustment = createVector(cos(beta), sin(beta));
          //computing the twistness of the branch at this moment
          if (k < 0) {
            pointB.lerp(pointA, 0.2);
          } else if (k < branchLength) {
            adjustment = createVector(cos(beta), sin(beta));
          } else {
            pointB.lerp(pointA, 0.9);
          }

          pointA.add(adjustment.mult(0.7));
          pointB.add(adjustment.mult(0.3));
          let pointC = pointA.copy();
          let pointD = pointB.copy();

          //line(pointA.x, pointA.y, pointB.x, pointB.y);

          arrayOfArrival.push([pointC, pointD]);
          //second attempt to make branches inward
        }
      }
    }
    /*
    << 3-2. The Branch System with RandomGaussian(firstly the parameters)
    By making a Vector of adjustment and add it to point A and B
    Arrival 6.0: try to load pixel and arrange to create the effect.
    */
  }
  z_off = 0;
  /*
  << 4-1. The Input settings (right before the setup ends)
  // */
  // textBox = createInput();
  // textBox.position(width / 2 - tbWidth / 2, height / 1.18 - tbHeight / 2);
  // textBox.size(tbWidth, tbHeight);
  // textBox.style("background", "rgba(255, 255, 255, 0)");
  // textBox.style("border", "none");
  // textBox.style("text-align", "center");
  // textBox.style("outline", "none");
  // textBox.attribute("placeholder", "Do you have any questions?");

  /*
  6-1. Input and Interaction
  */

  /*
  << TESTING >>
  */
  return arrayOfArrival;
}

function collect() {
  push();
  stroke(collectionColor);
  if (graphicsIndex < projectMax) {
    for (let i = 0; i < aoa.length; i++) {
      collection[graphicsIndex].line(
        aoa[i][0].x,
        aoa[i][0].y,
        aoa[i][1].x,
        aoa[i][1].y
      );
    }
    graphicsIndex++;
  }
  pop();
}

function displayAoa() {
  let pX;
  let pY;

  for (let i = 0; i < graphicsIndex + 1; i++) {
    pX = floor(i / rowNum);
    pY = i % rowNum;
    pX *= projectWidth - projectOffset;
    pY *= projectHeight;
    image(
      collection[i],
      pX,
      pY,
      width / proportionCollection,
      height / proportionCollection
    );
  }
}

function keyPressed() {
  if (keyCode === ENTER) {
    // Clear the input box when Enter is pressed
    textBox.value("");
  }
}

function mousePressed() {
  click = true;
  startingTime = millis();
  aoa = arrival();
}

function fakeClick() {
  click = true;
  startingTime = millis();
  aoa = arrival();
}

function keyReleased() {
  if (key == 's' || key == 'S') saveCanvas('Arrival(8.0)_Jiaqi_Yi', 'png');}
