function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  // if (random(1)===0.5)saveCanvas('test')
}