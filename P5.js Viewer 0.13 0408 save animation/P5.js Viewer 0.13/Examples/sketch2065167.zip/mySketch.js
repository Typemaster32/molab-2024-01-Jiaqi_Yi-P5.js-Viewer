/*
1. The control nums of the river
*/
const headNum = 2;
const headLength = 3;
const tailNum = 2;
const tailLength = 3;
const bodyLength = 3;
const allNum = headNum * tailNum;
const allLength = headLength + tailLength + bodyLength - 2;
let headLines = [];
let tailLines = [];
let bodyline;
let allLines = [];
var variation = 2.7;
/*
2. The settings factor of the flowing process
*/
var extraMargin;
var headKnotMargin;
var tailKnotMargin;
var bodyMargin;
//let direction;
const stepSize = 1;
const diameter = 1;
const devFactor = 0.3;
/*
3. The coordinate of each flow of the river
*/

function setup() {
  /*
  1. Basic settings
  */
  createCanvas(
    800,800 
  );
  angleMode(RADIANS);
  //fill(0, 40);
  strokeWeight(2);
  noFill();
  frameRate(1);
  var size = min(width, height);
  headKnotMargin = size / 3;
  tailKnotMargin = size / 3;
  bodyMargin = (size / 5) * 2;
  extraMargin = size / 4;
  /*
  2. Creating the array of control points.
  */
  let headKnot = createVector(
    random(headKnotMargin, bodyMargin*2),
    random(headKnotMargin, bodyMargin*2)
  );
  //console.log(headKnot.x, headKnot.y);
  let tailKnot = createVector(
    random(width / 2, width ),
    random(height / 2, height )
  );
  //console.log("bodyLine");
  bodyLine = new Polyline(headKnot, tailKnot, bodyLength);
  /*
  3. head lines;
  the first point has to be outside the screen;(top-left corner)
  */
  for (let i = 0; i < headNum; i++) {
    let headEndX = random((width*2) / 3);
    let headEndY = random(height / 2);
    if (random(1) > 0.5) headEndY = -15;
    else headEndX = -15;

    let headEnd = createVector(headEndX, headEndY);
    //console.log("headLine");
    let headLine = new Polyline(headEnd, headKnot, headLength);
    headLines.push(headLine);
  }
  /*
  4. The tail lines
  the last point has to be outside the screen;(buttom-right corner)*/
  for (let i = 0; i < tailNum; i++) {
    let tailEndX = random(width / 3, width);
    let tailEndY = random(height / 3, height);
    if (random(1) > 0.5) tailEndY = height;
    else tailEndX = width;
    let tailEnd = createVector(tailEndX, tailEndY);
    //console.log("tailLine");
    let tailLine = new Polyline(tailKnot, tailEnd, tailLength);
    tailLines.push(tailLine);
  }

  /*
  5. Compute all the chances, attaching each lane
  QUESTION: can the polyline be intersected by itself?
  */

  for (let i = 0; i < headNum; i++) {
    for (let j = 0; j < tailNum; j++) {
      let pl = headLines[i].duplicate();
      pl.aggregate(bodyLine);
      pl.aggregate(tailLines[j]);
      allLines.push(pl);
    }
  } /*
  6. Test
  */
  //background(155);
  // fill(255, 0, 0);
  // ellipse(headKnot.x, headKnot.y, 25, 25);
  // fill(0, 255, 0);
  // ellipse(tailKnot.x, tailKnot.y, 25, 25);
  // noFill();
  // for (let i = 0; i < allNum; i++) {
  //   beginShape();
  //   for (let j = 0; j < allLength; j++) {
  //     vertex(allLines[i].array[j].x, allLines[i].array[j].y);
  //   }
  //   endShape();
  // }
}

function draw() {
  background(255,98);
  noFill();
  strokeWeight(0.5);
  for (let i = 0; i < allNum; i++) {
    allLines[i].flow();
  }
}
function mousePressed() {
  variation += 0.1;
}
function flow() {
  let oX = x1;
  let oY = y1;
  let direction;
  for (let i = 0; i <= width * 10; i++) {
    direction = randomGaussian(2 * PI, 1.5);
    oX += cos(direction);
    oY += sin(direction);
    if (oX > width + extraMargin) (oX = x1), (oY = y1);
    if (oX < 0 - extraMargin) (oX = x1), (oY = y1);
    if (oY < 0 - extraMargin) (oX = x1), (oY = y1);
    if (oY > height + extraMargin) (oX = x1), (oY = y1);
    ellipse(oX + stepSize / 2, oY + stepSize / 2, diameter, diameter);
  }
}

class Polyline {
  constructor(pt1, pt2, lngth) {
    this.pt1 = pt1;
    this.pt2 = pt2;
    this.lngth = lngth;
    let md = createVector(pt2.x - pt1.x, pt2.y - pt1.y); //main direction
    this.md = md;
    let sec = createVector(
      (pt2.x - pt1.x) / (lngth + 1),
      (pt2.y - pt1.y) / (lngth + 1)
    ); //sections
    this.sec = sec;
    this.array = [this.pt1];
    for (let i = 1; i < lngth - 1; i++) {
      let body = pt1.copy();
      //console.log(body.x, body.y);
      //let bodyNew = p5.Vector.add(sec.mult(i), body);
      let devMag = sec.mag() * devFactor;
      let devTheta = random(2 * PI);
      let deviation = createVector(
        devMag * cos(devTheta),
        devMag * sin(devTheta)
      );
      body = p5.Vector.add(sec.mult(i), body);
      if (i != lngth - 2) body = p5.Vector.add(deviation, body);
      //console.log(body.x, body.y);
      this.array.push(body);
    }
    this.array.push(this.pt2);
    //console.log(this.lngth, this.array.length);
  }

  aggregate(polyL) {
    // Define more methods
    //console.log("try to attach");
    if (this.pt2.equals(polyL.pt1)) {
      for (let i = 1; i < polyL.lngth; i++) this.array.push(polyL.array[i]);
      this.pt2 = polyL.pt2;
      this.lngth += polyL.lngth - 1;
      //console.log("1-1");
    } else if (this.pt2.equals(polyL.pt2)) {
      for (let i = polyL.lngth - 2; i > 1; i--) this.array.push(polyL.array[i]);
      this.pt2 = polyL.pt1;
      this.lngth += polyL.lngth - 1;
      //console.log("1-2");
    } else {
      console.log("Error: Not Attached");
    }
  }
  duplicate() {
    let dupPt1 = this.pt1.copy();
    let dupPt2 = this.pt2.copy();
    let duplngth = this.lngth;
    let dupPolyLine = new Polyline(dupPt1, dupPt2, duplngth);
    for (let i = 0; i < duplngth; i++) {
      dupPolyLine.array[i] = this.array[i].copy();
    }
    //console.log(dupPolyLine);
    return dupPolyLine;
  }
  flow() {
    let oX = this.array[0].x;
    let oY = this.array[0].y;
    let direction;
    let trackIndex = 1;
    for (let i = 0; i <= width * variation * 15; i++) {
      let currentCentralDirection;
      let currentVector;
      currentVector = p5.Vector.sub(
        this.array[trackIndex - 1],
        this.array[trackIndex]
      );
      // currentCentralDirection =
      //   currentVector.y == 0
      //     ? currentVector.x / (currentVector.y + 1)
      //     : currentVector.x / currentVector.y;
      currentCentralDirection = currentVector.x / currentVector.y;
      direction = randomGaussian(currentCentralDirection, variation);
      oX += cos(direction) * stepSize;
      oY += sin(direction) * stepSize;
      strokeWeight(0.1);
      ellipse(oX + stepSize / 2, oY + stepSize / 2, diameter, diameter);

      if (trackIndex >= this.lngth) break;
      //console.log(oX, this.array[trackIndex].x);
      if (
        int(oX) == int(this.array[trackIndex].x) ||
        int(oY) == int(this.array[trackIndex].y)
      ) {
        //console.log("reach!");
        trackIndex++;
        continue;
      }
    }
  }
}function keyReleased() {
  if (key == 's' || key == 'S') saveCanvas('Twigs_Jiaqi_Yi', 'png');}
