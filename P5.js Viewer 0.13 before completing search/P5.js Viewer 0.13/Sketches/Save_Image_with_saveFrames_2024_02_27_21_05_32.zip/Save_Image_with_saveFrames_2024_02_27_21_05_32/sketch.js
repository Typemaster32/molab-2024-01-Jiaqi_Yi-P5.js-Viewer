function draw() {
  let r = frameCount % 255;
  let g = 50;
  let b = 100;
  background(r, g, b);
  text(frameCount,width/2,height/2)
  textAlign(CENTER)
  if (frameCount==1)saveFrames('frames', 'png', 15, 22);
}